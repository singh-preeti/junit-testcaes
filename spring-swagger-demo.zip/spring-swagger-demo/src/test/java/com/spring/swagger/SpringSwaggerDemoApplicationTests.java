package com.spring.swagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSwaggerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
